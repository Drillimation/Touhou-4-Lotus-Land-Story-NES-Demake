
/**
 * hex2int
 * take a hex string and convert it to a 32bit number (max 8 hex digits)
 */
unsigned int hex2uint(char *hex);