// This file implements the jni functions defined in
// "../net_gamephase_Audio_GameMusicEmu.h"

// Buffer size can be any multiple of 2
#define BUFFER_SIZE 760 

// Includes
#include <jni.h>
#include "Music_Emu.h"
#include "helpers.h"
#include "net_gamephase_Audio_GameMusicEmu.h"

// Empty string
char* _undefined = "";

// The global music emu and info objects
Music_Emu* emu;
track_info_t tinfo = {0}; 


// Load a song from data already in memory (previously created buffer in GMS)
// Data address pointer supplied as a long integer
// ---------------------------------------------------------------------------------
JNIEXPORT jdouble JNICALL Java_net_gamephase_Audio_GameMusicEmu_GameMusicEmu_1LoadBuffer
  (JNIEnv *env, jclass cl, jdouble size, jlong data_address)
{
	gme_err_t error = gme_open_data((const void*)data_address, (long)size, &emu, 44100);
	if(error == NULL)
		return 1; // OK
	else
		return 0; // Load Failed
}


// Get the number of tracks in the loaded file
// ---------------------------------------------------------------------------------
JNIEXPORT jdouble JNICALL Java_net_gamephase_Audio_GameMusicEmu_GameMusicEmu_1NumTracks
  (JNIEnv *env, jclass cl)
{
	if(emu)
		return (jdouble)emu->track_count();
	else
		return 0;
}


// Initialize a track, this function needs to be called before playback can start
// ---------------------------------------------------------------------------------
JNIEXPORT jdouble JNICALL Java_net_gamephase_Audio_GameMusicEmu_GameMusicEmu_1StartTrack
  (JNIEnv *env, jclass cl, jdouble trackNumber)
{
	blargg_err_t error;
	
	int track_nr = (int)trackNumber;
	if(track_nr >= emu->track_count())
		track_nr = emu->track_count()-1;
	error = emu->start_track( track_nr );
	if(error)
		return 0; // Could not set track number
	else {
		emu->track_info(&tinfo);
		return 1; // OK
	}
}


// Read song data into a memory buffer
// Buffer address supplied as a long integer
// ---------------------------------------------------------------------------------
JNIEXPORT jdouble JNICALL Java_net_gamephase_Audio_GameMusicEmu_GameMusicEmu_1Read
  (JNIEnv *env, jclass cl, jlong buffer_address)
{
	emu->play( BUFFER_SIZE, (short*)buffer_address );
	if(emu->track_ended())
		return 0; // Track ended
	else
		return 1;
}


// Get the number of voices used in the current song
// ---------------------------------------------------------------------------------
JNIEXPORT jdouble JNICALL Java_net_gamephase_Audio_GameMusicEmu_GameMusicEmu_1NumVoices
  (JNIEnv *env, jclass cl)
{
	if(emu)
		return (jdouble)emu->voice_count();
	else
		return 0;
}


// Mute / unmute a voice
// ---------------------------------------------------------------------------------
JNIEXPORT jdouble JNICALL Java_net_gamephase_Audio_GameMusicEmu_GameMusicEmu_1MuteVoice
  (JNIEnv *env, jclass cl, jdouble index, jdouble mute)
{
	bool m = false;
	if(mute > 0)
		m = true;
	
	if(emu) {
		emu->mute_voice((int)index, m);
		return 0;
	}
	else
		return 1;
}


// Mute / unmute voices according to a bitmask
// Ex: mask = 5 = B00000101 will mute voices 0 and 2
// ---------------------------------------------------------------------------------
JNIEXPORT jdouble JNICALL Java_net_gamephase_Audio_GameMusicEmu_GameMusicEmu_1MuteVoices
  (JNIEnv *env, jclass cl, jdouble mask)
{
	int m = (int)mask;

	if(emu) {
		emu->mute_voices(m);
		return 1;
	}
	else
		return 0;
}


// Set tempo
// Ex: 1 = normal speed, 1.5 = 150% speed, 2 = 200% speed
// ---------------------------------------------------------------------------------
JNIEXPORT jdouble JNICALL Java_net_gamephase_Audio_GameMusicEmu_GameMusicEmu_1SetTempo
  (JNIEnv *env, jclass cl, jdouble tempo)
{
	if(tempo > 0 && tempo <= 5)
		emu->set_tempo(tempo);
	return 1;
}

JNIEXPORT jdouble JNICALL Java_net_gamephase_Audio_GameMusicEmu_GameMusicEmu_1SetPosition
  (JNIEnv *env, jclass cl, jdouble msec)
{
	if(emu) {
		if(emu->seek((int)msec) == NULL)
			return 1;
		else
			return 0;
	}
	else
		return 0;
}

JNIEXPORT jdouble JNICALL Java_net_gamephase_Audio_GameMusicEmu_GameMusicEmu_1GetPosition
  (JNIEnv *env, jclass cl)
{
	if(emu) {
		return (double)emu->tell();
	}
	else
		return 0;
}

JNIEXPORT jdouble JNICALL Java_net_gamephase_Audio_GameMusicEmu_GameMusicEmu_1GetTrackLength
  (JNIEnv *env, jclass cl)
{
	if( emu ) 
		return (double)tinfo.length;
	else
		return -1;
}

JNIEXPORT jstring JNICALL Java_net_gamephase_Audio_GameMusicEmu_GameMusicEmu_1GetName
  (JNIEnv *env, jclass cl)
{
	jstring jstrBuf;
	if( emu ) {
		jstrBuf = env->NewStringUTF(tinfo.song);
		return jstrBuf;
	}
	else {
		jstrBuf = env->NewStringUTF(_undefined);
		return jstrBuf;
	}
}

JNIEXPORT jstring JNICALL Java_net_gamephase_Audio_GameMusicEmu_GameMusicEmu_1GetAuthor
  (JNIEnv *env, jclass cl)
{
	jstring jstrBuf;
	if( emu ) {
		jstrBuf = env->NewStringUTF(tinfo.author);
		return jstrBuf;
	}
	else {
		jstrBuf = env->NewStringUTF(_undefined);
		return jstrBuf;
	}
}

JNIEXPORT jstring JNICALL Java_net_gamephase_Audio_GameMusicEmu_GameMusicEmu_1GetCopyright
  (JNIEnv *env, jclass cl)
{
	jstring jstrBuf;
	if( emu ) {
		jstrBuf = env->NewStringUTF(tinfo.copyright);
		return jstrBuf;
	}
	else {
		jstrBuf = env->NewStringUTF(_undefined);
		return jstrBuf;
	}
}

JNIEXPORT jstring JNICALL Java_net_gamephase_Audio_GameMusicEmu_GameMusicEmu_1GetComment
  (JNIEnv *env, jclass cl)
{
	jstring jstrBuf;
	if( emu ) {
		jstrBuf = env->NewStringUTF(tinfo.comment);
		return jstrBuf;
	}
	else {
		jstrBuf = env->NewStringUTF(_undefined);
		return jstrBuf;
	}
}


// Free the memory associated with the music emu object
// ---------------------------------------------------------------------------------
JNIEXPORT jdouble JNICALL Java_net_gamephase_Audio_GameMusicEmu_GameMusicEmu_1Free
  (JNIEnv *env, jclass cl)
{
	if( emu ) {
		delete emu;
		return 1;
	}
	else
		return 0;
}